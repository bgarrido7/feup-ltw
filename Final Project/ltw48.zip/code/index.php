<?php
header('Location: pages/login.php');

?>