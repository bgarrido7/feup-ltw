<?php
 include_once(__DIR__.'/session.php');
 include_once(__DIR__.'/../database/connection.php');
?>