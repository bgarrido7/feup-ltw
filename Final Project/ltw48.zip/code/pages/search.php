<?php
include_once('../template/common/header.php');
include_once('../includes/init.php');
include_once("../template/common/aside.php");
include_once('../database/houses.php');
include_once("../template/titles/search.php");

include_once("../template/common/footer.php");
?>

