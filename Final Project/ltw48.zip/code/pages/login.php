<?php 
 include_once('../includes/init.php');
 include_once('../template/user/login.php');
 include_once('../template/common/footer.php');

 ?>