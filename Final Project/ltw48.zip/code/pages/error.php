<?php
include_once('../template/common/header.php');
?>
  <body>

  <p>go back my friend, you screwed up

  <a href="../index.php">homepage</a>
</body>

<?php

include_once("../template/common/footer.php");
?>