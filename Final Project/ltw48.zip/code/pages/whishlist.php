
<?php
include_once('../template/common/header.php');
include_once("../template/common/aside.php");
?>
    <div id="construction">
        <a>This page is still under construction</a>
    </div> 
</div>
<?php
include_once("../template/common/footer.php");

?>