<?php
include_once('../template/common/header.php');
include_once("../template/common/aside.php");

include_once("../template/dialogs/add_house.php");
include_once("../template/common/footer.php");
?>