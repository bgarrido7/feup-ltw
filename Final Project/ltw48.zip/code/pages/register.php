<?php
  include_once('../includes/init.php');
  include_once('../template/common/header_reg.php');
  include_once('../template/user/register.php');
  include_once('../template/common/footer.php');
?>

