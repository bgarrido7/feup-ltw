    <footer>
        <p>Copyright &copy; FEUP 2019
        <a href="https://github.com/bgarrido7/feup-ltw/tree/master/Final%20Project">

        <img src="../images/icons/git.png" alt="git" align="right" width="40" height="auto">
        </p>
    </footer>

</div>
</html>