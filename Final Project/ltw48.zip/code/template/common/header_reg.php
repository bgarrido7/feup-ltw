
<html>
<head>
    <title>Jūkyo</title>

    <meta charset="utf-8">
    <link rel="shortcut icon" href="../images/site/logo.svg" />
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Cherry+Swash" rel="stylesheet">
   <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" > 

  </head>
  <link rel="stylesheet" type="text/css" href="../css/style.css">
<body>
  
    <header id="menu-bar">
      <a href= "../index.php"><img src="../images/site/logo.png" alt="logo" width="50px"></a>
      <a href= "../index.php">Jūkyo</a>
    </header>
