

<div id="sidebar">
  <ul><a href="search.php">Search Houses</a></ul>
  <ul><a href="myReservations.php">Reservations</a></ul>
  <ul><a href="myHouses.php">My Houses</a></ul>
  <ul><a href="myRents.php">My Rented Houses</a></ul>
  <ul><a href="whishlist.php">Whishlist</a></ul>
  <ul><a href="profile.php">My Profile</a></ul>

<div id="logout">
<a href="../actions/action_logout.php">logout</a>
</div>

</div>