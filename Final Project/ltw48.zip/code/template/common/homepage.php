
<script src="../js/snow.js"></script>

<div id="homepage" >
<img src="../images/users/<?php echo htmlentities($userID);  ?>.jpg" alt="userPic">

    <h1> Welcome <?php echo htmlentities($name); ?> !<h1>


    <h2> Go away this holiday season, see our top pics: </h2>

