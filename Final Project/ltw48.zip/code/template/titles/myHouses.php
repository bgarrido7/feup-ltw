<div id="content">

<div id="new_house">
<input type="button" value="add new house" onclick="location='../pages/addHouse.php'"/>
</div>
<h1>My Houses</h1>
