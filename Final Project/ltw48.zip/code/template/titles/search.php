
<script src="../js/search.js" defer></script>

<div id="content">
    <div id="search_by">
        <i class="fa fa-search"></i>
        <input type="text" id="search" name="search">
        </br></br>
        <label> Location:
            <select name="city" id="city">
                <option value="null"> select an option </option>
                <option value="USA">USA</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Portugal">Portugal</option>
                <option value="Poland">Poland</option>
                <option value="Croatia">Croatia</option>
                <option value="Australia">Australia</option>
            </select> 
        </label>
        </br></br>
        <label>Price Range: </br>
          <input type="number" id="lowerPrice"> to
            <input type="number" id="upperPrice">
        </label>
    </div>

    <div id="filter_houses">
        <!--o javascript vai aparecer aqui magicamente-->
    </div>

</div>


