
<p><b>from </b><?php echo htmlentities($arrival);  ?>
 <b>to </b><?php echo htmlentities($departure);  ?> </p>
